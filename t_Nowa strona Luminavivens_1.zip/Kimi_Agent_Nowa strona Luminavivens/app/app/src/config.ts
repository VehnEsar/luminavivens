// Site-wide configuration
export interface SiteConfig {
  language: string;
  siteName: string;
  siteDescription: string;
}

export const siteConfig: SiteConfig = {
  language: "pl",
  siteName: "Lumina Vivens",
  siteDescription: "Żyjące Światło – Przestrzeń Świadomego Stworzenia. System duchowego rozwoju i transformacji.",
};

// Hero Section
export interface HeroConfig {
  backgroundImage: string;
  backgroundAlt: string;
  title: string;
  subtitle: string;
}

export const heroConfig: HeroConfig = {
  backgroundImage: "/hero-bg.jpg",
  backgroundAlt: "Eteryczny krajobraz ze złotym światłem",
  title: "Lumina Vivens",
  subtitle: "A Living Light System — Krzysztof Flejter",
};

// Narrative Text Section
export interface NarrativeTextConfig {
  line1: string;
  line2: string;
  line3: string;
}

export const narrativeTextConfig: NarrativeTextConfig = {
  line1: "Wybierz bramę i rozpocznij świadome przejście.",
  line2: "Przestrzeń Świadomego Stworzenia",
  line3: "Lumina Vivens to system transformacji prowadzący przez sześć bram do głębszej świadomości. Każda brama otwiera nową jakość doświadczania siebie i świata.",
};

// ZigZag Grid Section
export interface ZigZagGridItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  imageAlt: string;
  reverse: boolean;
}

export interface ZigZagGridConfig {
  sectionLabel: string;
  sectionTitle: string;
  items: ZigZagGridItem[];
}

export const zigZagGridConfig: ZigZagGridConfig = {
  sectionLabel: "Struktura Systemu",
  sectionTitle: "Sześć Bram Świadomości",
  items: [
    {
      id: "ogrod",
      title: "Ogród Energetyczny",
      subtitle: "Brama 01 — Przestrzeń Odnowy",
      description: "Miejsce regeneracji, harmonii i spokojnego przepływu. Po przejściu przez kamienne struktury wchodzisz w żywą przestrzeń światła, oddechu i subtelnego ruchu. Ogród prowadzi przez trzy strefy: oddech, regenerację i harmonię.",
      image: "/grid-1.jpg",
      imageAlt: "Ogród Energetyczny — przestrzeń odnowy",
      reverse: false,
    },
    {
      id: "woda",
      title: "Woda Kreacji",
      subtitle: "Brama 02 — Przestrzeń Przepływu",
      description: "Miejsce, w którym energia przestaje być tylko możliwością i zaczyna przyjmować ruch, kierunek oraz delikatną formę. Przepływ wody kreacji prowadzi przez trzy jakości: narodziny, ruch i kształtowanie.",
      image: "/card-3.jpg",
      imageAlt: "Woda Kreacji — przestrzeń przepływu",
      reverse: true,
    },
    {
      id: "miasto",
      title: "Kamienne Miasto",
      subtitle: "Brama 03 — Przestrzeń Pamięci",
      description: "Miejsce ciszy i obserwacji, gdzie kamień przechowuje historię świadomości, a każdy plac jest zapisem drogi, którą ktoś kiedyś przeszedł. Trzy przestrzenie prowadzą przez doświadczenie miasta: Brama Pamięci, Plac Ciszy i Krąg Przejścia.",
      image: "/grid-3.jpg",
      imageAlt: "Kamienne Miasto — przestrzeń pamięci",
      reverse: false,
    },
    {
      id: "elarion",
      title: "Elarion",
      subtitle: "Brama 05 — Przestrzeń Świadomości",
      description: "Elarion jest przestrzenią wejścia w wyższy porządek świadomości. To miejsce subtelnego światła, kierunku i spokojnego przebudzenia wewnętrznej drogi. Trzy filary Elarionu to: przebudzenie, świadomość i kierunek.",
      image: "/grid-2.jpg",
      imageAlt: "Elarion — przestrzeń świadomości",
      reverse: true,
    },
  ],
};

// Breath Section
export interface BreathSectionConfig {
  backgroundImage: string;
  backgroundAlt: string;
  title: string;
  subtitle: string;
  description: string;
}

export const breathSectionConfig: BreathSectionConfig = {
  backgroundImage: "/breath-bg.jpg",
  backgroundAlt: "Mistyczny ogród o świcie",
  title: "Pole Zerowe",
  subtitle: "Zatrzymaj wszystko. Wejdź w ciszę i ustaw punkt odniesienia.",
  description: "Punkt Zero to wejście bazowe do całej struktury Lumina Vivens. To miejsce, w którym zaczyna się świadoma podróż — od zatrzymania, przez obserwację, do transformacji. ∞.13.1",
};

// Card Stack Section
export interface CardStackItem {
  id: number;
  image: string;
  title: string;
  description: string;
  rotation: number;
}

export interface CardStackConfig {
  sectionTitle: string;
  sectionSubtitle: string;
  cards: CardStackItem[];
}

export const cardStackConfig: CardStackConfig = {
  sectionTitle: "Wybierz Swoją Bramę",
  sectionSubtitle: "Przejdź do wybranego obszaru i kontynuuj ruch przez strukturę Lumina Vivens",
  cards: [
    {
      id: 1,
      image: "/card-1.jpg",
      title: "Punkt Zero",
      description: "Zatrzymaj wszystko. Wejdź w ciszę i ustaw punkt odniesienia. Wejście bazowe do całej struktury.",
      rotation: -2,
    },
    {
      id: 2,
      image: "/card-2.jpg",
      title: "Ogród Energetyczny",
      description: "Uspokój ciało i oddech. Wejdź łagodnie w przestrzeń odczuwania. Miejsce regeneracji i harmonii.",
      rotation: 1,
    },
    {
      id: 3,
      image: "/card-3.jpg",
      title: "Woda Kreacji",
      description: "Uruchom przepływ. Zacznij świadomie tworzyć i kształtować energię. Przestrzeń narodzin ruchu.",
      rotation: -1,
    },
  ],
};

// Footer Section
export interface FooterContactItem {
  type: "email" | "phone";
  label: string;
  value: string;
  href: string;
}

export interface FooterSocialItem {
  platform: string;
  href: string;
}

export interface FooterConfig {
  heading: string;
  description: string;
  ctaText: string;
  contact: FooterContactItem[];
  locationLabel: string;
  address: string[];
  socialLabel: string;
  socials: FooterSocialItem[];
  logoText: string;
  copyright: string;
  links: { label: string; href: string }[];
}

export const footerConfig: FooterConfig = {
  heading: "Rozpocznij Swoją Podróż",
  description: "Lumina Vivens to przestrzeń świadomego stworzenia. Wybierz bramę, która rezonuje z Tobą w tej chwili i pozwól prowadzić się przez transformację.",
  ctaText: "Wejdź do Systemu",
  contact: [
    {
      type: "email",
      label: "kontakt@luminavivens.com",
      value: "kontakt@luminavivens.com",
      href: "mailto:kontakt@luminavivens.com",
    },
  ],
  locationLabel: "Lokalizacja",
  address: ["Przestrzeń Świadomego Stworzenia", "Polska"],
  socialLabel: "Śledź",
  socials: [
    {
      platform: "instagram",
      href: "https://instagram.com/luminavivens",
    },
    {
      platform: "facebook",
      href: "https://facebook.com/luminavivens",
    },
  ],
  logoText: "Lumina Vivens",
  copyright: "© 2026 Lumina Vivens. Wszelkie prawa zastrzeżone.",
  links: [
    { label: "Polityka Prywatności", href: "#" },
    { label: "Regulamin", href: "#" },
  ],
};
